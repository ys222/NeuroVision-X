from src.neurovisionx.data.synthetic import make_synthetic_grid
if __name__ == "__main__":
    make_synthetic_grid()
    print("Synthetic samples created in data/sample/images")
