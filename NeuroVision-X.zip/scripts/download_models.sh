#!/usr/bin/env bash
set -e
echo "[stub] Add commands to fetch SAM/DINO/VideoMAE checkpoints here."
