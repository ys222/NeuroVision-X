import torch, torch.nn as nn

class QFormerLite(nn.Module):
    def __init__(self, vision_dim=384, text_dim=384, hidden=384, num_queries=16):
        super().__init__()
        self.queries = nn.Parameter(torch.randn(num_queries, hidden))
        self.v_proj = nn.Linear(vision_dim, hidden)
        self.t_proj = nn.Linear(text_dim, hidden)
        self.cross = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=hidden, nhead=8, batch_first=True), num_layers=2
        )
    def forward(self, v_feats, t_feats):
        v = self.v_proj(v_feats).unsqueeze(1)  # [B,1,H]
        t = self.t_proj(t_feats).unsqueeze(1)
        q = self.queries.unsqueeze(0).expand(v.size(0), -1, -1)
        x = torch.cat([q, v, t], dim=1)
        return self.cross(x)[:, 0]  # pooled query token
