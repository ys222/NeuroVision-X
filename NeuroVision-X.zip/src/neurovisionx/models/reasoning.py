# Lightweight "reasoning" adapter that mocks an LLM call for offline demo.
def reason(context: dict, question: str) -> str:
    # In real use, call an LLM here. For demo, return a templated rationale.
    domain = context.get("domain", "generic")
    return (
        f"[Reasoning::{domain}] Given signals {list(context.keys())}, "
        f"my short answer to '{question}' is: this requires further evidence. "
        f"(Demo adapter—plug your LLM here)"
    )
