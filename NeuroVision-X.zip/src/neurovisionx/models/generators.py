# Stubs that simulate image/3D generation for demos without heavy weights.
from PIL import Image, ImageDraw
import numpy as np

def generate_image_stub(prompt: str, size=(512,512)):
    img = Image.new("RGB", size, (30,30,30))
    d = ImageDraw.Draw(img)
    d.text((10,10), f"GenImage: {prompt[:28]}")
    for i in range(0, size[0], 32):
        d.line([(i,0),(i,size[1])])
        d.line([(0,i),(size[0],i)])
    return img

def generate_3d_stub(prompt: str):
    # Return a trivial .obj content as a placeholder.
    vertices = ["v 0 0 0", "v 1 0 0", "v 0 1 0"]
    faces = ["f 1 2 3"]
    return "\n".join(vertices + faces)
