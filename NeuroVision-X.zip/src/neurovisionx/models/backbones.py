import torch, torch.nn as nn

class DinoLite(nn.Module):
    def __init__(self, hidden=384):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(3, hidden//6, 3, 2, 1),
            nn.ReLU(),
            nn.Conv2d(hidden//6, hidden//3, 3, 2, 1),
            nn.ReLU(),
            nn.Conv2d(hidden//3, hidden, 3, 2, 1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1,1)),
        )
        self.proj = nn.Linear(hidden, hidden)
    def forward(self, x):
        feats = self.encoder(x).flatten(1)
        return self.proj(feats)

class VideoMAELite(nn.Module):
    def __init__(self, hidden=384):
        super().__init__()
        self.temporal = nn.GRU(hidden, hidden, batch_first=True)
    def forward(self, frame_feats):
        out, _ = self.temporal(frame_feats)
        return out[:, -1]
