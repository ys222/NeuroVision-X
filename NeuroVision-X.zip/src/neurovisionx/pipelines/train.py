from ..data.synthetic import make_synthetic_grid
from ..utils.metrics import simple_metrics
def train_dummy():
    make_synthetic_grid()
    preds = [1,1,0,1]; gts = [1,0,0,1]
    return simple_metrics(preds, gts)
if __name__ == "__main__":
    print(train_dummy())
