import argparse, pathlib
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', type=str, required=True)
    args = ap.parse_args()
    out = pathlib.Path('artifacts'); out.mkdir(exist_ok=True)
    (out / 'model.onnx').write_bytes(b'fake-onnx')
    print(f'Exported demo ONNX to {out / "model.onnx"}')
if __name__ == "__main__":
    main()
