from ..models.generators import generate_image_stub
from ..models.reasoning import reason

def multimodal_infer(prompt: str, domain: str = "industrial"):
    img = generate_image_stub(prompt)
    rationale = reason({"domain": domain, "image": "stub"}, f"Assess: {prompt}")
    return img, rationale

if __name__ == "__main__":
    img, r = multimodal_infer("detect sparks near operator")
    img.save("generated.png")
    print(r)
