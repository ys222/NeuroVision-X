from fastapi import FastAPI, UploadFile, File, Form
from pydantic import BaseModel
from ..pipelines.infer import multimodal_infer
from io import BytesIO
from PIL import Image

app = FastAPI(title="NeuroVision-X API", version="0.1.0")

class InferOut(BaseModel):
    rationale: str

@app.post("/infer", response_model=InferOut)
async def infer(prompt: str = Form(...)):
    img, rationale = multimodal_infer(prompt)
    buf = BytesIO()
    img.save(buf, format="PNG")
    # Normally we'd return image bytes; to keep it simple, we return rationale only.
    return {"rationale": rationale}

@app.get("/health")
def health():
    return {"ok": True}
