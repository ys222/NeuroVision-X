import streamlit as st
from ..pipelines.infer import multimodal_infer

st.set_page_config(page_title="NeuroVision-X Dashboard", layout="wide")
st.title("🧠 NeuroVision-X — Cross-Modal Perception & Reasoning")

prompt = st.text_input("Describe the task or scene:", "detect sparks near operator in thermal feed")
domain = st.selectbox("Domain", ["industrial", "healthcare", "autonomous", "arvr"])

if st.button("Run Inference"):
    img, rationale = multimodal_infer(prompt, domain)
    c1, c2 = st.columns([2,1])
    with c1:
        st.image(img, caption="Generated/annotated visualization")
    with c2:
        st.markdown("**Reasoning Trace**")
        st.code(rationale)
st.caption("Demo build — wire up real backbones/LLMs via configs.")
