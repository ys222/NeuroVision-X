from PIL import Image, ImageDraw
from pathlib import Path
import random

def make_synthetic_grid(root='data/sample/images', n=6, size=(256,256)):
    Path(root).mkdir(parents=True, exist_ok=True)
    for i in range(n):
        img = Image.new('RGB', size, (random.randint(0,50),)*3)
        d = ImageDraw.Draw(img)
        for j in range(0, size[0], 32):
            d.line([(j,0),(j,size[1])])
            d.line([(0,j),(size[0],j)])
        d.text((8,8), f"sample_{i}")
        img.save(f"{root}/sample_{i}.png")
