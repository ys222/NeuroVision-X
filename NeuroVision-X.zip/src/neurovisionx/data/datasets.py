from pathlib import Path
from PIL import Image
import numpy as np

class SampleImageDataset:
    def __init__(self, root='data/sample/images'):
        self.paths = list(Path(root).glob('*.png'))
    def __len__(self):
        return len(self.paths)
    def __getitem__(self, idx):
        img = Image.open(self.paths[idx]).convert('RGB')
        arr = np.array(img)/255.0
        return arr
