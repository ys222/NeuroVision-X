from typing import Dict, Any
def simple_metrics(preds, gts) -> Dict[str, Any]:
    # placeholder metrics
    acc = float((preds == gts).mean()) if hasattr(preds, "mean") else 0.0
    return {"acc": acc}
