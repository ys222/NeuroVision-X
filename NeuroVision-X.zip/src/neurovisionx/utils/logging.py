from loguru import logger
logger.add(lambda msg: None)  # no-op sink for packaged use
