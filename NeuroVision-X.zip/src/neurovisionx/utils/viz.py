from PIL import Image, ImageDraw, ImageFont
def draw_box(img: Image.Image, box, text=None):
    d = ImageDraw.Draw(img)
    d.rectangle(box, outline=(255,0,0), width=2)
    if text:
        d.text((box[0], max(0, box[1]-12)), text)
    return img
