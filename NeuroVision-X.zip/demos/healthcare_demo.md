# Healthcare Demo (Research-Only)
- Input: CT/MRI slices + radiology note.
- Output: Anomaly markers + report alignment summary.
**Note:** For educational purposes only. Do not use clinically.
