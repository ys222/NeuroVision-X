# Industrial Safety Demo
- Input: RGB frame + (optional) thermal map + text instruction.
- Output: Risk heatmap + natural-language rationale.
Steps:
1) Run dashboard, choose **industrial** domain.
2) Enter prompt like: "detect sparks near operator".
3) Observe generated overlay and reasoning trace.
TODO: connect real thermal camera and SDXL/ControlNet for overlays.
